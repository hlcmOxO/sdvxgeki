#pragma once
#include <stdint.h>

#include <HID-Project.h>

#include "components/manager.hpp"
